from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# Knowledge base for the chatbot
admission_responses = {
    "greeting": ["Hello! Welcome to University Admission Help. How can I assist you today?", 
                "Hi there! I'm here to help with university admission queries. What would you like to know?"],
    "programs": ["We offer undergraduate programs in Computer Science, Engineering, Business Administration, and Liberal Arts.", 
                "Our graduate programs include MBA, MS in Computer Science, and PhD in various disciplines."],
    "requirements": ["For undergraduate programs, you need a high school diploma with minimum 75% marks. For graduate programs, a bachelor's degree is required.",
                   "General requirements include academic transcripts, recommendation letters, and a statement of purpose. International students need TOEFL/IELTS scores."],
    "deadlines": ["Fall semester deadline: July 15\nSpring semester deadline: November 15", 
                 "Application deadlines vary by program. Most programs have rolling admissions."],
    "fees": ["Undergraduate tuition is $20,000 per year. Graduate tuition varies from $15,000 to $25,000 depending on the program.",
             "We offer various scholarships and financial aid options. Would you like more information about financial assistance?"],
    "scholarships": ["We offer merit-based scholarships ranging from $2,000 to full tuition. You're automatically considered when you apply.",
                    "There are also need-based grants and work-study programs available."],
    "campus": ["Our 200-acre campus has modern facilities including libraries, labs, sports complexes, and student housing.",
              "We have 5 academic buildings, 3 residence halls, and extensive recreational facilities."],
    "contact": ["You can reach our admission office at admission@university.edu or call +1 (555) 123-4567.",
               "Our mailing address is: Admission Office, University Name, 123 College St, City, State, ZIP"],
    "fallback": ["I'm not sure I understand. Could you rephrase your question?", 
                "I don't have information about that. Would you like to speak with an admission counselor?"],
    "goodbye": ["Thank you for contacting us. Good luck with your application!", 
               "We hope to see you on campus soon! Have a great day."]
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def get_response():
    user_message = request.form["user_message"].lower()
    
    # Simple intent recognition
    if any(word in user_message for word in ["hi", "hello", "hey"]):
        response = random.choice(admission_responses["greeting"])
    elif any(word in user_message for word in ["program", "course", "major", "study"]):
        response = random.choice(admission_responses["programs"])
    elif any(word in user_message for word in ["require", "need", "eligibility", "criteria"]):
        response = random.choice(admission_responses["requirements"])
    elif any(word in user_message for word in ["deadline", "date", "when", "apply"]):
        response = random.choice(admission_responses["deadlines"])
    elif any(word in user_message for word in ["fee", "cost", "tuition", "price"]):
        response = random.choice(admission_responses["fees"])
    elif any(word in user_message for word in ["scholarship", "financial aid", "funding"]):
        response = random.choice(admission_responses["scholarships"])
    elif any(word in user_message for word in ["campus", "facility", "library", "housing"]):
        response = random.choice(admission_responses["campus"])
    elif any(word in user_message for word in ["contact", "email", "phone", "address"]):
        response = random.choice(admission_responses["contact"])
    elif any(word in user_message for word in ["bye", "goodbye", "thanks", "thank you"]):
        response = random.choice(admission_responses["goodbye"])
    else:
        response = random.choice(admission_responses["fallback"])
    
    return jsonify({"bot_response": response})

if __name__ == "__main__":
    app.run(debug=True)