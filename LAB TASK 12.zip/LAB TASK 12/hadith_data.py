hadith_collection = {
    "prayer": "The Prophet ﷺ said: 'The closest a servant comes to his Lord is when he is prostrating.' (Sahih Muslim)",
    "fasting": "The Prophet ﷺ said: 'Whoever fasts during Ramadan with faith and seeking his reward from Allah will have his past sins forgiven.' (Bukhari & Muslim)",
    "charity": "The Prophet ﷺ said: 'Charity does not decrease wealth.' (Muslim)",
    "kindness": "The Prophet ﷺ said: 'Allah is kind and loves kindness in all matters.' (Bukhari)",
    "knowledge": "The Prophet ﷺ said: 'Seeking knowledge is an obligation upon every Muslim.' (Ibn Majah)",
    "honesty": "The Prophet ﷺ said: 'Truthfulness leads to righteousness, and righteousness leads to Paradise.' (Bukhari & Muslim)",
    "parents": "The Prophet ﷺ said: 'Paradise lies under the feet of mothers.' (Nasai)",
    "anger": "The Prophet ﷺ said: 'The strong is not the one who overcomes people by his strength, but the one who controls himself while in anger.' (Bukhari)",
    "mercy": "The Prophet ﷺ said: 'He who does not show mercy to others will not be shown mercy.' (Bukhari & Muslim)",
    "neighbors": "The Prophet ﷺ said: 'He is not a believer whose neighbor is not safe from his harm.' (Bukhari)",
    "justice": "The Prophet ﷺ said: 'Help your brother, whether he is an oppressor or he is oppressed.' (Bukhari)",
    "smile": "The Prophet ﷺ said: 'Your smile for your brother is a charity.' (Tirmidhi)",
    "intention": "The Prophet ﷺ said: 'Actions are but by intentions.' (Bukhari & Muslim)",
    "modesty": "The Prophet ﷺ said: 'Modesty is part of faith.' (Bukhari)",
    "gratitude": "The Prophet ﷺ said: 'He who does not thank people, does not thank Allah.' (Tirmidhi)",
    "trust": "The Prophet ﷺ said: 'When a man is made a ruler over the people and he dies while dishonest in his dealings, he will not even smell the fragrance of Paradise.' (Bukhari)",
    "brotherhood": "The Prophet ﷺ said: 'None of you truly believes until he loves for his brother what he loves for himself.' (Bukhari & Muslim)",
    "greed": "The Prophet ﷺ said: 'If the son of Adam had a valley full of gold, he would like to have two valleys.' (Bukhari & Muslim)",
    "envy": "The Prophet ﷺ said: 'Do not envy one another, and do not inflate prices among yourselves.' (Muslim)",
    "dua": "The Prophet ﷺ said: 'Dua is the essence of worship.' (Tirmidhi)",
    "sincerity": "The Prophet ﷺ said: 'Religion is sincerity.' (Muslim)",
    "hypocrisy": "The Prophet ﷺ said: 'The signs of a hypocrite are three: When he speaks, he lies; when he promises, he breaks it; and when he is trusted, he betrays.' (Bukhari & Muslim)",
    "truth": "The Prophet ﷺ said: 'Truthfulness leads to righteousness, and righteousness leads to Paradise.' (Bukhari)",
    "lying": "The Prophet ﷺ said: 'Beware of lying, for lying leads to wickedness and wickedness leads to the Fire.' (Bukhari)",
    "arrogance": "The Prophet ﷺ said: 'No one who has an atom's weight of arrogance in his heart will enter Paradise.' (Muslim)",
    "forgiveness": "The Prophet ﷺ said: 'Show mercy to others and you will receive mercy.' (Tirmidhi)",
    "repentance": "The Prophet ﷺ said: 'Every son of Adam sins, and the best of sinners are those who repent.' (Tirmidhi)",
    "patience": "The Prophet ﷺ said: 'Whoever remains patient, Allah will make him patient. Nobody can be given a blessing better and greater than patience.' (Bukhari)",
    "generosity": "The Prophet ﷺ said: 'The upper hand is better than the lower hand (i.e., he who gives is better than he who takes).' (Bukhari)",
    "humility": "The Prophet ﷺ said: 'Whoever humbles himself for Allah, Allah will raise him.' (Muslim)",
    "death": "The Prophet ﷺ said: 'Remember often the destroyer of pleasures (i.e., death).' (Tirmidhi)",
    "wealth": "The Prophet ﷺ said: 'Riches does not mean having a great amount of property, but riches is self-contentment.' (Bukhari & Muslim)",
    "speech": "The Prophet ﷺ said: 'Whoever believes in Allah and the Last Day should speak a good word or remain silent.' (Bukhari & Muslim)",
    "time": "The Prophet ﷺ said: 'There are two blessings which many people lose: health and free time.' (Bukhari)",
    "help": "The Prophet ﷺ said: 'Whoever removes a worldly hardship from a believer, Allah will remove a hardship from him on the Day of Resurrection.' (Muslim)",
    "food": "The Prophet ﷺ said: 'The best among you is he who invites others to eat and greets with peace.' (Bukhari)",
    "sleep": "The Prophet ﷺ said: 'When one of you goes to sleep, he should shake off his bed with his garment, for he does not know what may have entered it.' (Bukhari)",
    "women": "The Prophet ﷺ said: 'The best of you are those who are best to their women.' (Tirmidhi)",
    "children": "The Prophet ﷺ said: 'He is not of us who does not have mercy on young children and respect the elderly.' (Tirmidhi)",
    "animals": "The Prophet ﷺ said: 'A woman was punished in Hell because of a cat which she had confined until it died.' (Bukhari)",
    "cleanliness": "The Prophet ﷺ said: 'Cleanliness is half of faith.' (Muslim)",
    "salutation": "The Prophet ﷺ said: 'Spread peace among yourselves.' (Muslim)",
    "intoxicants": "The Prophet ﷺ said: 'Whatever intoxicates in large amounts, a small amount of it is also forbidden.' (Tirmidhi)",
    "backbiting": "The Prophet ﷺ said: 'Do you know what backbiting is? It is to mention about your brother that which he dislikes.' (Muslim)",
    "salah": "The Prophet ﷺ said: 'The first matter that the slave will be brought to account for on the Day of Judgment is the prayer.' (Tirmidhi)",
    "friday": "The Prophet ﷺ said: 'The best day on which the sun has risen is Friday.' (Muslim)",
    "islam": "The Prophet ﷺ said: 'Islam is built upon five pillars.' (Bukhari & Muslim)",
    "quran": "The Prophet ﷺ said: 'The best of you are those who learn the Quran and teach it.' (Bukhari)",
    "zakat": "The Prophet ﷺ said: 'Protect your wealth by paying Zakat.' (Bayhaqi)"
}

def get_hadith_response(user_input):
    user_input = user_input.lower()
    for topic, hadith in hadith_collection.items():
        if topic in user_input:
            return hadith
    return (
        "Sorry, I couldn't find a relevant Hadith. "
        "Try asking about another topic."
    )
