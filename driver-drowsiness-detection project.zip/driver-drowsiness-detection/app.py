import cv2
import numpy as np
import threading
import os
from flask import Flask, render_template, Response, jsonify
import mediapipe as mp
import webbrowser
import pygame

app = Flask(__name__)


pygame.mixer.init()


mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=False,
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7
)


mp_drawing = mp.solutions.drawing_utils


drowsiness_detected = False
head_pose_alert = False
alert_active = False
video_capture = None
EYE_AR_THRESH = 0.23
EYE_AR_CONSEC_FRAMES = 45
COUNTER = 0
alert_count = 0
lock = threading.Lock()
HEAD_POSE_COUNTER = 0
HEAD_POSE_CONSEC_FRAMES = 60 


LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]
NOSE_TIP = 1


ALERT_SOUND_PATH = os.path.join('static', 'audio', 'alert.mp3')


def eye_aspect_ratio(eye):
    A = np.linalg.norm(eye[1] - eye[5])
    B = np.linalg.norm(eye[2] - eye[4])
    C = np.linalg.norm(eye[0] - eye[3])
    return (A + B) / (2.0 * C)

def play_alert_sound(sound_path):
    global alert_active , COUNTER ,alert_count
    with lock:
        if not alert_active:
            alert_active = True
            alert_count += 1
            try:
                pygame.mixer.music.load(sound_path)
                pygame.mixer.music.play()
                print("Alert sound playing...")
                threading.Timer(2.0, set_alert_inactive).start()
            except Exception as e:
                print(f"Error playing sound: {e}")

def set_alert_inactive():
    global alert_active , COUNTER
    with lock:
        alert_active = False
        print("Alert sound reset.")

def detect_drowsiness(frame, landmarks, w, h):
    global COUNTER, drowsiness_detected
    try:
        left_eye = np.array([[landmarks[p].x * w, landmarks[p].y * h] for p in LEFT_EYE])
        right_eye = np.array([[landmarks[p].x * w, landmarks[p].y * h] for p in RIGHT_EYE])

        left_ear = eye_aspect_ratio(left_eye)
        right_ear = eye_aspect_ratio(right_eye)
        ear = (left_ear + right_ear) / 2.0

        if ear < EYE_AR_THRESH:
            COUNTER += 1
            if COUNTER >= EYE_AR_CONSEC_FRAMES:
                with lock:
                    drowsiness_detected = True
                play_alert_sound(ALERT_SOUND_PATH)
                cv2.putText(frame, "DROWSINESS ALERT!", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        else:
            with lock:
                COUNTER = 0
                drowsiness_detected = False

        cv2.polylines(frame, [left_eye.astype(np.int32)], True, (0, 255, 0), 1)
        cv2.polylines(frame, [right_eye.astype(np.int32)], True, (0, 255, 0), 1)
        cv2.putText(frame, f"EAR: {ear:.2f}", (300, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
    except Exception as e:
        print(f"EAR Calculation Error: {e}")
        with lock:
            drowsiness_detected = False
            COUNTER = 0

def detect_head_pose(frame, landmarks, w, h):
    global head_pose_alert, HEAD_POSE_COUNTER

    nose_x = landmarks[NOSE_TIP].x * w
    frame_center_x = w // 2
    left_threshold = w * 0.12
    right_threshold = w * 0.10

    # Draw visual thresholds
    # cv2.line(frame, (int(frame_center_x - left_threshold), 0), (int(frame_center_x - left_threshold), h), (255, 255, 0), 1)
    # cv2.line(frame, (int(frame_center_x + right_threshold), 0), (int(frame_center_x + right_threshold), h), (0, 255, 255), 1)

    direction = ""
    if nose_x < frame_center_x - left_threshold:
        direction = "Looking Left"
        HEAD_POSE_COUNTER += 1
    elif nose_x > frame_center_x + right_threshold:
        direction = "Looking Right"
        HEAD_POSE_COUNTER += 1
    else:
        direction = "Looking Center"
        HEAD_POSE_COUNTER = 0
        with lock:
            head_pose_alert = False

    if direction != "Looking Center" and HEAD_POSE_COUNTER >= HEAD_POSE_CONSEC_FRAMES:
        with lock:
            head_pose_alert = True
        play_alert_sound(ALERT_SOUND_PATH)
        cv2.putText(frame, f"{direction} ALERT!", (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

    cv2.putText(frame, f"Head: {direction}", (300, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 255), 2)

def process_frame(frame):
    frame = cv2.flip(frame, 1)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(rgb_frame)

    if results.multi_face_landmarks:
        h, w = frame.shape[:2]
        landmarks = results.multi_face_landmarks[0].landmark

        detect_drowsiness(frame, landmarks, w, h)
        detect_head_pose(frame, landmarks, w, h)
    else:
        with lock:
            drowsiness_detected = False
            head_pose_alert = False
        cv2.putText(frame, "NO FACE DETECTED", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

    return frame

def generate_frames():
    global video_capture
    video_capture = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    video_capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    video_capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    while True:
        success, frame = video_capture.read()
        if not success:
            break
        frame = process_frame(frame)
        ret, buffer = cv2.imencode('.jpg', frame)
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/check_status')
def check_status():
    with lock:
        return jsonify({
            'drowsiness_detected': drowsiness_detected,
            'head_pose_alert': head_pose_alert,
            'alert_count': COUNTER  
        })

def cleanup():
    global video_capture
    if video_capture is not None:
        video_capture.release()
    face_mesh.close()

def open_browser():
    webbrowser.open_new("http://127.0.0.1:10000")

if __name__ == '__main__':
    try:
        threading.Timer(1.0, open_browser).start()
        app.run(host='0.0.0.0', port=10000, threaded=True)
    finally:
        cleanup()
