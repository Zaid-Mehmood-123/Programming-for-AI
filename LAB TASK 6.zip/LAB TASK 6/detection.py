import cv2
import numpy as np
import folium
import os
import geocoder

net = cv2.dnn.readNet("yolo/yolov3.weights", "yolo/yolov3.cfg")
layer_names = net.getLayerNames()
output_layers = [layer_names[i - 1] for i in net.getUnconnectedOutLayers().flatten()]

with open("yolo/coco.names", "r") as f:
    classes = [line.strip() for line in f.readlines()]

ANIMAL_CLASSES = ["donkey","sheep", "cow", "horse", "bear", "zebra", "giraffe", "elephant"]

def get_current_location():
    """Get current location using IP address or GPSD"""
    try:
        import gpsd
        gpsd.connect()
        packet = gpsd.get_current()
        return packet.lat, packet.lon
    except:
        g = geocoder.ip('me')
        if g.latlng:
            return g.latlng[0], g.latlng[1]
        else:
            return 51.5074, -0.1278  

def create_alert_map(lat, lon, animal, count):
    """Create interactive map with alert marker"""
    m = folium.Map(location=[lat, lon], zoom_start=14)

    folium.Marker(
        [lat, lon],
        popup=f"🛑 HERD ALERT\n{count} {animal}s",
        icon=folium.Icon(color='red', icon='exclamation-triangle')
    ).add_to(m)

    folium.Marker(
        [lat, lon],
        popup="Your Location",
        icon=folium.Icon(color='blue', icon='user')
    ).add_to(m)

    folium.TileLayer(
        tiles='https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attr='Esri',
        name='Satellite',
        overlay=False,
        control=True
    ).add_to(m)

    m.save("map_alert.html")
    print(f"Map alert saved with coordinates: {lat:.4f}, {lon:.4f}")

def detect_herd(image_path):
    """Main detection function with real-time location"""
    lat, lon = get_current_location()
    print(f"📍 Current location: {lat:.4f}, {lon:.4f}")

    if not os.path.exists(image_path):
        print(f"❌ Error: File '{image_path}' not found.")
        return

    img = cv2.imread(image_path)
    if img is None:
        print(f"❌ Error: Unable to load image at {image_path}")
        return

    height, width, _ = img.shape

    blob = cv2.dnn.blobFromImage(img, 0.00392, (416, 416), (0, 0, 0), True, crop=False)
    net.setInput(blob)
    outs = net.forward(output_layers)


    boxes = []
    confidences = []
    class_ids = []

    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]

            if confidence > 0.5 and classes[class_id] in ANIMAL_CLASSES:
                center_x = int(detection[0] * width)
                center_y = int(detection[1] * height)
                w = int(detection[2] * width)
                h = int(detection[3] * height)

                x = int(center_x - w / 2)
                y = int(center_y - h / 2)

                boxes.append([x, y, w, h])
                confidences.append(float(confidence))
                class_ids.append(class_id)

    indexes = cv2.dnn.NMSBoxes(boxes, confidences, 0.5, 0.4)

    animal_counts = {}
    font = cv2.FONT_HERSHEY_SIMPLEX

    for i in range(len(boxes)):
        if i in indexes:
            x, y, w, h = boxes[i]
            label = str(classes[class_ids[i]])
            confidence = confidences[i]
            color = (0, 255, 0)

            animal_counts[label] = animal_counts.get(label, 0) + 1

            cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
            cv2.putText(img, f"{label} {confidence:.2f}", (x, y - 10), font, 0.5, color, 1)

    alert_triggered = False
    for animal, count in animal_counts.items():
        if count >= 3:
            print(f"🚨 HERD ALERT: {count}  detected!")
            create_alert_map(lat, lon, animal, count)
            alert_triggered = True

    if not alert_triggered:
        print("✅ No herds detected.")

    cv2.imshow("Detection Results", img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

image_path = r"D:\SEMSETER 4\PAI LAB\LAB TASK 6\donkey_images.jpeg"
if not os.path.exists(image_path):
    print(f"❌ Error: File '{image_path}' does not exist.")
else:
    print(f"📂 File '{image_path}' found.")
    detect_herd(image_path)
