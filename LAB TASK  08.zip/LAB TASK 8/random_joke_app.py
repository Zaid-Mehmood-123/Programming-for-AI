from flask import Flask, render_template, request
import requests

app = Flask(__name__)

CATEGORIES = ["Programming", "Miscellaneous", "Puns", "Spooky", "Dark", "Christmas"]

@app.route('/', methods=['GET', 'POST'])
def home():
    category = request.form.get('category', 'Programming') 
    
    url = f'https://v2.jokeapi.dev/joke/{category}?type=single'
    response = requests.get(url)
    
    if response.status_code == 200:
        joke_data = response.json()
        joke = joke_data.get("joke", "No joke found.")
    else:
        joke = "Failed to fetch a joke. Please try again."

    return render_template('index.html', joke=joke, categories=CATEGORIES, category=category)

if __name__ == '__main__':
    app.run(debug=True)
